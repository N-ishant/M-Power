import React from 'react'

function MyPieChart() {
  return (
    <div>
      hh
    </div>
  )
}

export default MyPieChart

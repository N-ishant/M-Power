import React, { useState, useEffect } from "react";
import {
  Typography,
  Box,
  Grid,
  Card,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  ListItemText,
  OutlinedInput,
  Chip,
} from "@mui/material";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedSkills, setSelectedTechnologies, setSelectedTools, setSelectedEmployees } from "../feature/apiDataSlice";
const AddSkillsAndExperience = () => {
  const dispatch = useDispatch();
  const baseURL = "https://staffcentral.azurewebsites.net/api";
  const [skillsOptions, setSkillsOptions] = useState([]);
  const [technologyOptions, setTechnologyOptions] = useState([]);
  const [toolsOptions, setToolsOptions] = useState([]);
  const [selectedSkills, setSelectedSkills] = useState({});
  const [selectedTechnologies, setSelectedTechnologies] = useState({});
  const [selectedTools, setSelectedTools] = useState({});
  const [checkedRows, setCheckedRows] = useState(new Set());
  const selectedEmployees = useSelector((state) => state.apiData.selectedEmployees);

  useEffect(() => {
    // Retrieve saved checked rows from local storage
    const savedCheckedRows = localStorage.getItem('checkedRows');
    if (savedCheckedRows) {
      setCheckedRows(new Set(JSON.parse(savedCheckedRows)));
    }

    const savedSkills = localStorage.getItem("selectedSkills");
    const savedTechnologies = localStorage.getItem("selectedTechnologies");
    const savedTools = localStorage.getItem("selectedTools");
   

    if (savedSkills) {
      setSelectedSkills(JSON.parse(savedSkills));
    }
    if (savedTechnologies) {
      setSelectedTechnologies(JSON.parse(savedTechnologies));
    }
    if (savedTools) {
      setSelectedTools(JSON.parse(savedTools));
    }
  }, []);
  
  
  
  
  useEffect(() => {
    if (checkedRows.size > 0) {
      const checkedSkills = {};
      const checkedTechnologies = {};
      const checkedTools = {};
      checkedRows.forEach(empcode => {
        checkedSkills[empcode] = selectedSkills[empcode];
        checkedTechnologies[empcode] = selectedTechnologies[empcode];
        checkedTools[empcode] = selectedTools[empcode];
      });
      localStorage.setItem("selectedSkills", JSON.stringify(checkedSkills));
      localStorage.setItem("selectedTechnologies", JSON.stringify(checkedTechnologies));
      localStorage.setItem("selectedTools", JSON.stringify(checkedTools));
    }
  }, [checkedRows, selectedSkills, selectedTechnologies, selectedTools]);

  useEffect(() => {
    if (selectedEmployees.length > 0) {
      refreshSkillsList();
      refreshTechnologyList();
      refreshToolsList();
      const empCodes = selectedEmployees.join(",");
      if (empCodes) {
        fetchExistingData(empCodes);
      }
    } else {
      // Clear local storage if no employees are selected
      localStorage.removeItem("selectedSkills");
      localStorage.removeItem("selectedTechnologies");
      localStorage.removeItem("selectedTools");
      setSelectedSkills({});
      setSelectedTechnologies({});
      setSelectedTools({});
    }
  }, [selectedEmployees]);

  const refreshSkillsList = () => {
    axios
      .get(`${baseURL}/SkillMaster/GetAllSkill`)
      .then((response) => {
        setSkillsOptions(response.data);
      })
      .catch((error) => {
        console.error("Error fetching skills:", error);
      });
  };

  const refreshTechnologyList = () => {
    axios
      .get(`${baseURL}/Technology/GetTechnologys`)
      .then((response) => {
        setTechnologyOptions(response.data);
      })
      .catch((error) => {
        console.error("Error fetching technologies:", error);
      });
  };

  const refreshToolsList = () => {
    const empCodes = selectedEmployees.join(",");
    axios
      .get(`${baseURL}/CreateEmployeeCV/GetCreateEmployeeSkillTechCVToolsByEmpCodes`, {
        params: { empCodes: empCodes },
      })
      .then((response) => {
        const toolsByEmployee = response.data.reduce((acc, item) => {
          if (!acc[item.empcode]) {
            acc[item.empcode] = { employeeName: item.employeeName, tools: item.tool.split(", ") };
          } else {
            acc[item.empcode].tools = [...new Set([...acc[item.empcode].tools, ...item.tool.split(", ")])];
          }
          return acc;
        }, {});
        setSelectedTools(toolsByEmployee);
      })
      .catch((error) => {
        console.error("Error fetching tools:", error);
      });
  };

  const fetchExistingData = (empCodes) => {
    const storedSkills = JSON.parse(localStorage.getItem("selectedSkills") || '{}');
    const storedTechnologies = JSON.parse(localStorage.getItem("selectedTechnologies") || '{}');
    const storedTools = JSON.parse(localStorage.getItem("selectedTools") || '{}');

    const apiEmpCodes = empCodes.split(',').filter(empcode => 
      !storedSkills[empcode] && !storedTechnologies[empcode] && !storedTools[empcode]
    ).join(',');

    if (apiEmpCodes) {
      axios
        .get(`${baseURL}/CreateEmployeeCV/GetCreateEmployeeCVSkillsByEmpCodes`, { params: { empCodes: apiEmpCodes } })
        .then((response) => {
          if (response.data.length > 0) {
            const employeeData = response.data;
            const skillsByEmployee = employeeData.reduce((acc, item) => {
              if (!acc[item.empcode]) {
                acc[item.empcode] = { employeeName: item.employeeName, skills: [] };
              }
              acc[item.empcode].skills.push(item.skillId);
              return acc;
            }, {});
            setSelectedSkills(prev => ({ ...prev, ...skillsByEmployee }));
          }
        })
        .catch((error) => {
          console.error("Error fetching existing skills:", error);
        });

      axios
        .get(`${baseURL}/CreateEmployeeCV/GetCreateEmployeeCVTechnologyByEmpCodes`, { params: { empCodes: apiEmpCodes } })
        .then((response) => {
          if (response.data.length > 0) {
            const employeeData = response.data;
            const technologiesByEmployee = employeeData.reduce((acc, item) => {
              if (!acc[item.empcode]) {
                acc[item.empcode] = { employeeName: item.employeeName, technologies: [] };
              }
              acc[item.empcode].technologies.push(item.technologyId);
              return acc;
            }, {});
            setSelectedTechnologies(prev => ({ ...prev, ...technologiesByEmployee }));
          }
        })
        .catch((error) => {
          console.error("Error fetching existing technologies:", error);
        });
    }
  };

  const handleSkillChange = (empcode) => (event) => {
    const newSkills = event.target.value;
    setSelectedSkills((prevSelectedSkills) => ({
      ...prevSelectedSkills,
      [empcode]: { ...prevSelectedSkills[empcode], skills: newSkills },
    }));
  };

  const handleTechnologyChange = (empcode) => (event) => {
    const newTechnologies = event.target.value;
    setSelectedTechnologies((prevSelectedTechnologies) => ({
      ...prevSelectedTechnologies,
      [empcode]: { ...prevSelectedTechnologies[empcode], technologies: newTechnologies },
    }));
  };

  const handleToolChange = (empcode) => (event) => {
    const newTools = event.target.value;
    setSelectedTools((prevSelectedTools) => ({
      ...prevSelectedTools,
      [empcode]: { ...prevSelectedTools[empcode], tools: newTools },
    }));
  };

  const handleCheckboxToggle = (empcode, type, id) => {
    const setSelectedState = type === 'skills' ? setSelectedSkills : type === 'technologies' ? setSelectedTechnologies : setSelectedTools;
    setSelectedState((prevSelectedState) => {
      const selected = prevSelectedState[empcode]?.[type] || [];
      const updatedState = selected.includes(id) ? selected.filter(item => item !== id) : [...selected, id];
      if (checkedRows.has(empcode)) {
        localStorage.setItem(`selected${type.charAt(0).toUpperCase() + type.slice(1)}`, JSON.stringify({
          ...prevSelectedState,
          [empcode]: { ...prevSelectedState[empcode], [type]: updatedState }
        }));
      }
      sendDataToServer(empcode, type, updatedState);
      return {
        ...prevSelectedState,
        [empcode]: { ...prevSelectedState[empcode], [type]: updatedState },
      };
    });
  };

  const sendDataToServer = (empcode, type, updatedState) => {
    const apiEndpoint = type === 'skills'
      ? `${baseURL}/CreateEmployeeCV/UpdateEmployeeSkills`
      : type === 'technologies'
        ? `${baseURL}/CreateEmployeeCV/UpdateEmployeeTechnologies`
        : `${baseURL}/CreateEmployeeCV/UpdateEmployeeTools`;
    axios
      .post(apiEndpoint, { empcode, [type]: updatedState })
      .then((response) => {
        console.log(`${type.charAt(0).toUpperCase() + type.slice(1)} updated successfully:`, response.data);
      })
      .catch((error) => {
        console.error(`Error updating ${type}:`, error);
      });
  };

  const handleRowCheckboxChange = (empcode) => (event) => {
    const checked = event.target.checked;
    setCheckedRows((prevCheckedRows) => {
      const newCheckedRows = new Set(prevCheckedRows);
  
      if (checked) {
        // Add to checked rows
        newCheckedRows.add(empcode);
      } else {
        // Remove from checked rows
        newCheckedRows.delete(empcode);
        
        // Check if the employee is no longer in selectedEmployees
        if (!selectedEmployees.includes(empcode)) {
          // Update selectedEmployees by removing the unchecked employee
          const updatedSelectedEmployees = selectedEmployees.filter(emp => emp !== empcode);
          dispatch(setSelectedEmployees(updatedSelectedEmployees)); // Update Redux state
  
          // Clear employee-specific data from state
          const updatedSkills = { ...selectedSkills };
          const updatedTechnologies = { ...selectedTechnologies };
          const updatedTools = { ...selectedTools };
          delete updatedSkills[empcode];
          delete updatedTechnologies[empcode];
          delete updatedTools[empcode];
          setSelectedSkills(updatedSkills);
          setSelectedTechnologies(updatedTechnologies);
          setSelectedTools(updatedTools);
  
          // Remove employee-specific data from local storage
          localStorage.setItem("selectedSkills", JSON.stringify(updatedSkills));
          localStorage.setItem("selectedTechnologies", JSON.stringify(updatedTechnologies));
          localStorage.setItem("selectedTools", JSON.stringify(updatedTools));
        }
  
        // Re-hit the API for unchecked employees
        const empCodesToFetch = Array.from(newCheckedRows).join(",");
        if (empCodesToFetch) {
          fetchExistingData(empCodesToFetch);
        }
      }
  
      // Save to local storage
      localStorage.setItem('checkedRows', JSON.stringify(Array.from(newCheckedRows)));
  
      return newCheckedRows;
    });
  };
  
  
  return (
    <Card sx={{ minWidth: 275, mt: 0, pb: 0 }} className="border-0">
      <form className="tondform-css form-validation-p">
        {Object.keys(selectedSkills).map((empcode) => (
          <Grid container spacing={2} key={empcode}>
            <Grid item xs={12} sx={{ mt: 2, mb: 0, pl: 0, pr: 0 }}>
              <Typography variant="h6">
                Employee Name: {selectedSkills[empcode]?.employeeName}
              </Typography>
            </Grid>
            
            <Grid item xs={6} sx={{ mt: 2, mb: 0, pl: 0, pr: 0 }}>
              <FormControl fullWidth>
                <InputLabel id={`skills-label-${empcode}`}>Skills</InputLabel>
                <Select
                  labelId={`skills-label-${empcode}`}
                  id={`skills-${empcode}`}
                  multiple
                  value={selectedSkills[empcode]?.skills || []}
                  onChange={handleSkillChange(empcode)}
                  input={<OutlinedInput label="Skills" />}
                  renderValue={(selected) => (
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip
                          key={value}
                          label={
                            skillsOptions.find(
                              (option) => option.skillId === value
                            )?.name || value
                          }
                        />
                      ))}
                    </Box>
                  )}
                >
                  {skillsOptions.map((option) => (
                    <MenuItem key={option.skillId} value={option.skillId}>
                      <Checkbox
                        checked={
                          selectedSkills[empcode]?.skills?.includes(option.skillId) || false
                        }
                        onChange={() =>
                          handleCheckboxToggle(empcode, 'skills', option.skillId)
                        }
                      />
                      <ListItemText primary={option.name} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6} sx={{ mt: 2, mb: 0, pl: 0, pr: 0 }}>
              <FormControl fullWidth>
                <InputLabel id={`technology-label-${empcode}`}>Technologies</InputLabel>
                <Select
                  labelId={`technology-label-${empcode}`}
                  id={`technology-${empcode}`}
                  multiple
                  value={selectedTechnologies[empcode]?.technologies || []}
                  onChange={handleTechnologyChange(empcode)}
                  input={<OutlinedInput label="Technologies" />}
                  renderValue={(selected) => (
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip
                          key={value}
                          label={
                            technologyOptions.find(
                              (option) => option.technologyId === value
                            )?.technologyName || value
                          }
                        />
                      ))}
                    </Box>
                  )}
                >
                  {technologyOptions.map((option) => (
                    <MenuItem key={option.technologyId} value={option.technologyId}>
                      <Checkbox
                        checked={
                          selectedTechnologies[empcode]?.technologies?.includes(option.technologyId) || false
                        }
                        onChange={() =>
                          handleCheckboxToggle(empcode, 'technologies', option.technologyId)
                        }
                      />
                      <ListItemText primary={option.technologyName} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={6} sx={{ mt: 2, mb: 0, pl: 0, pr: 0 }}>
              <FormControl fullWidth>
                <InputLabel id={`tools-label-${empcode}`}>Tools</InputLabel>
                <Select
                  labelId={`tools-label-${empcode}`}
                  id={`tools-${empcode}`}
                  multiple
                  value={selectedTools[empcode]?.tools || []}
                  onChange={handleToolChange(empcode)}
                  input={<OutlinedInput label="Tools" />}
                  renderValue={(selected) => (
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip
                          key={value}
                          label={value}
                        />
                      ))}
                    </Box>
                  )}
                >
                  {/* Options could be dynamically populated or statically set */}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={1} sx={{ mt: 2, mb: 0, pl: 0, pr: 0, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <Checkbox
                checked={checkedRows.has(empcode)}
                onChange={handleRowCheckboxChange(empcode)}
              />
            </Grid>
          </Grid>
        ))}
      </form>
    </Card>
  );
};

export default AddSkillsAndExperience;

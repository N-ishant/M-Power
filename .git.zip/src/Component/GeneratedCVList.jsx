import React, { useState, useEffect } from 'react';
import {
    Table, TableBody, Checkbox, TableCell, TableContainer, TableHead, TableRow,
    Paper, TablePagination, TableSortLabel, TextField,
    IconButton,
    Grid,
    styled
} from '@mui/material';
import { useTheme } from '@mui/material/styles'; 
import useMediaQuery from '@mui/material/useMediaQuery';
import { Add, Delete, Edit } from '@mui/icons-material';
import SearchIcon from '@mui/icons-material/Search';
import { Button, Box } from '@mui/material';
import SkillmasterForm from './SkillMasterForm';
import CachedIcon from '@mui/icons-material/Cached';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

const createData = (id, ClientName,EmployeeName,TemplateName, Email, MobileNo) => {
    return { id, ClientName,EmployeeName ,TemplateName, Email, MobileNo};
}

const rows = [
    createData(1, 'Client Name 1','Employee Name 1', 'Basic', 'email1@gmail.com','1234567890'),
    createData(2, 'Client Name 2','Employee Name 2', 'Advanced', 'email2@gmail.com','1234567890'),
    
    // Add more rows as needed
];

const GeneratedCVList = () => {
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5); 
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('ClientName');
    const [search, setSearch] = useState('');
    const [filteredRows, setFilteredRows] = useState(rows);

    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));

    useEffect(() => {
        setFilteredRows(
            rows.filter(row => row.ClientName.toLowerCase().includes(search.toLowerCase()))
        );
    }, [search]);

    const handleRequestSort = (property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleSearchChange = (event) => {
        setSearch(event.target.value);
    };

    const sortComparator = (a, b) => {
        if (b[orderBy] < a[orderBy]) {
            return order === 'asc' ? -1 : 1;
        }
        if (b[orderBy] > a[orderBy]) {
            return order === 'asc' ? 1 : -1;
        }
        return 0;
    };

    const sortedRows = [...filteredRows].sort(sortComparator);

    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    }));

    const [showDiv, setShowDiv] = useState(false);
    const handleDownload = () => {
        // setShowDiv((prevShowDiv) => !prevShowDiv);
        console.log("CV Downloaded")
    };

    return (
        <Paper sx={{ width: '100%', overflow: 'hidden', mb:2 }} className='form-card-css'>
            {showDiv && (
                <Box className="">
                    <SkillmasterForm />
                </Box>
            )}

            <Grid container spacing={0}>

                <Grid item xs={7}>
                </Grid>
{/* 
                <Grid item xs={2} textAlign={'right'} >
                    
                    <Button sx={{ mt: 3  }} variant="contained" color="primary" onClick={handleDownload}>
                        {'View as PDF'}
                    </Button>
                </Grid>
                 */}
                <Grid item xs={2} textAlign={'right'} sx={{ mt: 2.80 }}>
                    
                    <Button  variant="contained" className="primary mr-10" onClick={handleDownload}>
                        {'Download'}
                    </Button>
                </Grid>
               
                <Grid item xs={3} sx={{ pr: 2 }}>
                    <Item>
                        <TextField
                         className='search-css'
                            placeholder="Search CV"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={search}
                            onChange={handleSearchChange}
                        />
                        <SearchIcon className='search-icon' />
                    </Item>
                </Grid>
            </Grid>

            <TableContainer>
                <Table sx={{ minWidth: 650 }} aria-label="enhanced table">
                    <TableHead>
                        <TableRow>
                        <TableCell style={{ width: 50 }}>S.No</TableCell>
                            <TableCell>
                                Select
                            </TableCell>

                            <TableCell>
                                <TableSortLabel
                                    active={orderBy === 'ClientName'}
                                    direction={orderBy === 'ClientName' ? order : 'asc'}
                                    onClick={() => handleRequestSort('ClientName')}
                                >
                                    Client Name
                                </TableSortLabel>
                            </TableCell>

                            <TableCell>Employee Name</TableCell>
                            <TableCell>Template Name</TableCell>
                            <TableCell>Email </TableCell>
                            <TableCell>Mobile No. </TableCell>


                            {/* <TableCell></TableCell> */}
                            {/* {!isSmallScreen && (
                                <>
                                    <TableCell></TableCell>
                                </>
                            )} */}
                            <TableCell align="right">
                                <TableSortLabel
                                    active={orderBy === 'Action'}
                                    direction={orderBy === 'Action' ? order : 'asc'}
                                    onClick={() => handleRequestSort('Action')}
                                >
                                    Action
                                </TableSortLabel>
                            </TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {sortedRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (

                            <TableRow key={row.id}>
 <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                                {!isSmallScreen && <TableCell>
                                    <Checkbox />
                                </TableCell>}
                                <TableCell>
                                    {row.ClientName}
                                </TableCell>
                                <TableCell>
                                    {row.EmployeeName}
                                </TableCell>
                                <TableCell>
                                    {row.TemplateName}
                                </TableCell>
                                <TableCell>
                                    {row.Email}
                                </TableCell>
                                <TableCell>
                                    {row.MobileNo}
                                </TableCell>
                                {/* {!isSmallScreen && <TableCell></TableCell>} */}
                                {/* {!isSmallScreen && <TableCell></TableCell>} */}
                                <TableCell align="right">
                                    <IconButton className='viewAsPdfIconCss'><PictureAsPdfIcon/></IconButton>
                                    <IconButton className='downloadIconCss'> <FileDownloadIcon /></IconButton>
                                    <IconButton className='deletecss'><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M21 5.98c-3.33-.33-6.68-.5-10.02-.5-1.98 0-3.96.1-5.94.3L3 5.98M8.5 4.97l.22-1.31C8.88 2.71 9 2 10.69 2h2.62c1.69 0 1.82.75 1.97 1.67l.22 1.3M18.85 9.14l-.65 10.07C18.09 20.78 18 22 15.21 22H8.79C6 22 5.91 20.78 5.8 19.21L5.15 9.14M10.33 16.5h3.33M9.5 12.5h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={filteredRows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
        </Paper>
    );
};

export default GeneratedCVList;

import React, { useState, useEffect } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import the styles
import Loader from "../Component/Loader";
import {
  Box,
  Button,
  Grid,
  Card,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Checkbox,
} from "@mui/material";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedObjectiveDetails } from "../feature/apiDataSlice";
const Objective = () => {
  const baseURL = "https://staffcentral.azurewebsites.net/api";
  const selectedEmployees = useSelector((state) => state.apiData.selectedEmployees);
  const datas = useSelector((state) => state.apiData.selectedObjectiveDetails);
  console.log(datas);
  
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [value, setValue] = useState(""); // Value for ReactQuill
  const [objectiveName, setObjectiveName] = useState(
    localStorage.getItem("selectedObjectiveName") || ""
  ); // Preserve selected objective
  const [isCheckboxChecked, setIsCheckboxChecked] = useState(
    JSON.parse(localStorage.getItem("isCheckboxChecked")) || false
  ); // Retrieve checkbox state from localStorage
  
  const dispatch = useDispatch(); // Initialize dispatch

  // Fetch the list of objectives
  const refreshList = () => {
    if (!isCheckboxChecked && selectedEmployees.length > 0) {
      // API call is only made if the checkbox is unchecked and selectedEmployees is not empty
      const empCodes = selectedEmployees.join(",");
      console.log("Fetching data for employee codes: ", empCodes); // Debugging: Check if empCodes are correct
      axios
        .get(`${baseURL}/CreateEmployeeCV/GetEmployeeCVDetails`, {
          params: { empCodes: empCodes },
        })
        .then((response) => {
          //console.log("API response:", response.data); // Debugging: Check API response
          if (response.data && response.data.employeeCVObjectiveDetails) {
            setData(response.data.employeeCVObjectiveDetails);
            // Dispatch action to update Redux state
            dispatch(setSelectedObjectiveDetails(response.data.employeeCVObjectiveDetails));
          } else {
            console.error("Unexpected API response format:", response.data);
          }
          setLoading(false);
        })
        .catch((error) => {
          console.error(
            "Error fetching data:",
            error.response || error.message
          );
          setLoading(false);
        });
    } else {
      console.log(
        "Skipping API call: Checkbox checked or no selected employees."
      );
      setLoading(false); // Prevent infinite loading state
    }
  };

  useEffect(() => {
    if (selectedEmployees.length === 0) {
      localStorage.removeItem("objectiveData");
      localStorage.removeItem("selectedObjectiveName");
      localStorage.removeItem("isCheckboxChecked");
      setData([]);
      setValue("");
      setObjectiveName("");
      setIsCheckboxChecked(false);
    } else {
      refreshList(); // Only refresh if checkbox is unchecked
    }
  }, [selectedEmployees, isCheckboxChecked]);

  useEffect(() => {
    const savedData = localStorage.getItem("objectiveData");
    if (savedData) {
      const parsedData = JSON.parse(savedData);
      setData(parsedData);
      const savedObjectiveName = localStorage.getItem("selectedObjectiveName");
      if (savedObjectiveName) {
        setObjectiveName(savedObjectiveName);
        const selectedObjective = parsedData.find(
          (item) => item.employeeCode === savedObjectiveName
        );
        if (selectedObjective) {
          setValue(selectedObjective.objectiveDescription || "");
        }
      }
    }
  }, []);

  useEffect(() => {
    if (selectedEmployees.length > 0) {
      localStorage.setItem("objectiveData", JSON.stringify(data));
      localStorage.setItem("selectedObjectiveName", objectiveName);
      localStorage.setItem(
        "isCheckboxChecked",
        JSON.stringify(isCheckboxChecked)
      ); // Store checkbox state
    }
  }, [data, objectiveName, selectedEmployees, isCheckboxChecked]);

  // Handle selection change
  const handleModuleChange = (event) => {
    const selectedObjectiveName = event.target.value;
    setObjectiveName(selectedObjectiveName);

    // Find the selected objective
    const selectedObjective = data.find(
      (item) => item.employeeCode === selectedObjectiveName
    );
    if (selectedObjective) {
      const { objectiveDescription } = selectedObjective;
      setValue(objectiveDescription || "");
    } else {
      setValue("");
    }

    // Update the selected objective in localStorage
    localStorage.setItem("selectedObjectiveName", selectedObjectiveName);
  };

  const handleClear = () => {
    setValue("");
    localStorage.removeItem("objectiveDescription");
  };

  const handleDescriptionChange = (content) => {
    setValue(content);
    const updatedData = data.map((item) =>
      item.employeeCode === objectiveName
        ? { ...item, objectiveDescription: content }
        : item
    );
    setData(updatedData);
    localStorage.setItem("objectiveData", JSON.stringify(updatedData));
    // Dispatch action to update Redux state
    dispatch(setSelectedObjectiveDetails(updatedData));
  };

  const handleCheckboxChange = (event) => {
    const checked = event.target.checked;
    setIsCheckboxChecked(checked);
    localStorage.setItem("isCheckboxChecked", JSON.stringify(checked)); // Update checkbox state in localStorage
  };

  if (loading) {
    return <Typography><Loader /></Typography>;
  }
  return (
    <Card sx={{ minWidth: 275, mt: 0, pb: 1 }} className="border-0">
      <Grid container spacing={2} sx={{ mt: -2 }}>
        <Grid
          item
          xs={12}
          sx={{ mt: 1, mb: 0, pl: 0, pr: 0 }}
          className="tondform-css form-card-css_2 form-validation-p"
        >
          <FormControl fullWidth>
            <InputLabel id="module-name-label">Select Objective</InputLabel>
            <Select
              labelId="module-name-label"
              id="module-name-select"
              value={objectiveName}
              label="Objective Name"
              onChange={handleModuleChange}
              disabled={isCheckboxChecked} // Disable the dropdown when the checkbox is checked
            >
              {data.map((item) => (
                <MenuItem key={item.employeeCode} value={item.employeeCode}>
                  {item.employeeObjective}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={12} sx={{ mt: 1, mb: 0, pl: 0, pr: 0 }}>
          <Typography variant="h5" className="title-b" sx={{ mb: 2 }}>
            Description
          </Typography>
          <ReactQuill
            key={objectiveName}
            value={value}
            onChange={handleDescriptionChange}
            theme="snow"
            placeholder="Write something..."
            style={{ height: "200px", marginBottom: "20px" }}
            readOnly={isCheckboxChecked} // Disable editing when checkbox is checked
          />
        </Grid>
      </Grid>
      <Box sx={{ mt: 5 }}>
        <Button
          variant="contained"
          color="secondary"
          onClick={handleClear}
          disabled={isCheckboxChecked}
        >
          Clear
        </Button>
        <Checkbox
          checked={isCheckboxChecked}
          onChange={handleCheckboxChange}
          color="primary"
          sx={{ ml: 2 }}
        />
        please Select
      </Box>
    </Card>
  );
};

export default Objective;

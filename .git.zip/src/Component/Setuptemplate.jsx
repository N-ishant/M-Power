import React, { useState, useEffect } from "react";
import {
  Card,
  MenuItem,
  Button,
  InputLabel,
  FormControl,
  Grid,
  Select,
  Typography,
} from "@mui/material";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedClientName, setSelectedTemplateName, setSelectedpdfData, setSelectedBasicInformation } from "../feature/apiDataSlice";
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import CvPdfList from "./CvPdfList";
import { useNavigate } from "react-router-dom";

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));
function Setuptemplate() {
  const navigate = useNavigate();
  const [ClientNames, setClientNames] = useState([]);
  const [TemplateNames, setTemplateNames] = useState([]);
  const dispatch = useDispatch();
  const selectedClient = useSelector((state) => state.apiData.selectedClientName);
  const selectedTemplate = useSelector((state) => state.apiData.selectedTemplateName);
  const selectedData = useSelector((state)=> state.apiData.selectedpdfData);
  //console.log(selectedData);
  const baseURL = "https://staffcentral.azurewebsites.net/api";
  const selectedEmployees = useSelector(
    (state) => state.apiData.selectedEmployees
  );
  
  // Fetch client names when component loads
  useEffect(() => {
    axios
      .get(`${baseURL}/CreateEmployeeCV/GetAllClient`)
      .then((response) => {
        setClientNames(response.data);
      })
      .catch((error) => {
        console.error("Error fetching client names!", error);
      });
  }, []);

  // Fetch template names when component loads
  useEffect(() => {
    axios
      .get(`${baseURL}/CreateEmployeeCV/GetAllTemplate`)
      .then((response) => {
        setTemplateNames(response.data);
      })
      .catch((error) => {
        console.error("Error fetching template names!", error);
      });
  }, []);

  const handleClientChange = (event) => {
    const selectedClient = event.target.value;
    dispatch(setSelectedClientName(selectedClient));
  };

  const handleTemplateChange = (event) => {
    const selectedTemplate = event.target.value;
    dispatch(setSelectedTemplateName(selectedTemplate));
  };

  // Function to handle the "View as PDF" button click
  const handleViewAsPDF = () => {
    navigate("/CvPdfList");
    // setOpen(true);
    if (!selectedTemplate) {
      alert("Please select a template first!");
      return;
    }

    const templateId = TemplateNames.find(
      (template) => template.templateName === selectedTemplate
    )?.templateId;

    if (templateId) {
      axios
        .get(`${baseURL}/Teamplate/GetTemplateById?TemplateId=${templateId}`)
        .then((response) => {
          dispatch(setSelectedpdfData(response.data));
        })
        .catch((error) => {
          console.error("Error fetching template PDF data!", error);
        });
    }
  };
  
  const [data, setData] = useState([]);
  const refreshList = () => {
    const empCodes = selectedEmployees.join(",");
    axios
      .get(`${baseURL}/CreateEmployeeCV/GetEmployeeCVBasicInfoByEmpCodes`, {
        params: { empCodes: empCodes },
      })
      .then((response) => {
        setData(response.data);
        dispatch(setSelectedBasicInformation(response.data));
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  useEffect(() => {
    refreshList();
  }, []);
  return (
    <Card className="border-0">
      <form className="tondform-css form-validation-p">
        <Grid container>
          <Grid item xs={5} sx={{ mt: 2, mb: 0, pl: 0, pr: 2 }}>
            <FormControl fullWidth>
              <InputLabel id="client-name-label">Choose Client Name</InputLabel>
              <Select
                labelId="client-name-label"
                id="client-name-select"
                value={selectedClient}
                label="Choose Client Name"
                onChange={handleClientChange}
              >
                {ClientNames.map((item) => (
                  <MenuItem key={item.clientId} value={item.clientName}>
                    {item.clientName.trim()}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={5} sx={{ mt: 2, mb: 0, pl: 0, pr: 2 }}>
            <FormControl fullWidth>
              <InputLabel id="template-name-label">Choose Template Name</InputLabel>
              <Select
                labelId="template-name-label"
                id="template-name-select"
                value={selectedTemplate}
                label="Choose Template Name"
                onChange={handleTemplateChange}
              >
                {TemplateNames.map((template) => (
                  <MenuItem key={template.templateId} value={template.templateName}>
                    {template.templateName.trim()}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={2} sx={{ mt: 2, mb: 0, pl: 0, pr: 0 }}>
            <Button
              className="wt-100 primary"
              variant="contained"
              onClick={handleViewAsPDF}
            >
              View as PDF
            </Button>
          </Grid>
        </Grid>
      </form>
      {/* <React.Fragment>
      <BootstrapDialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
      > */}
        {/* <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          CV Template
        </DialogTitle> */}
        {/* <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={(theme) => ({
            position: 'absolute',
            right: 8,
            top: 8,
            color: theme.palette.grey[500],
          })}
        >
          <CloseIcon />
        </IconButton> */}
        {/* <DialogContent dividers> */}
          {/* <CvPdfList/> */}
        {/* </DialogContent> */}
        {/* <DialogActions>
          <Button autoFocus onClick={handleClose}>
            Save changes
          </Button>
        </DialogActions> */}
      {/* </BootstrapDialog>
    </React.Fragment> */}
    </Card>
  );
}

export default Setuptemplate;

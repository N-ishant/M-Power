// import React from "react";
// import Grid from "@mui/material/Grid";
// import { useSelector } from "react-redux";

// function CvPdfList() {
//   const selectedData = useSelector((state) => state.apiData.selectedpdfData);
//   const objDataName = useSelector((state)=> state.apiData.selectedObjDataName);
//   const objDataDes = useSelector((state)=> state.apiData.selectedObjDes);
//   const expDetailsData = useSelector((state)=> state.apiData.selectedExperienceDetails);
//   const projectDetailsData = useSelector((state)=> state.apiData.selectedProjectDetails);
//   const basicInfoData  = useSelector((state)=>state.apiData.selectedBasicInformation);
//   console.log(basicInfoData);
//   console.log(expDetailsData);
//   console.log(projectDetailsData);

//   return (
//     <Box>

//       <Grid container spacing={2}>
//         <Grid item xs={12}>
//           <Box className="prfile-cv-section">
//             <Box className="circle-img-section"></Box>
//             <Box className="pf-img-section">
//               {selectedData.name && <Box>Name</Box>}
//               {selectedData.designation && <Box>Designation</Box>}
//               <Box>
//                 {selectedData.email && "Email"} | {selectedData.mobileNo && "Mobile"} | {selectedData.linkedInId && "LinkedIn"}
//               </Box>
//             </Box>
//           </Box>
//         </Grid>

//         {/* Objective Section */}
//         {selectedData.objectiveName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Objective:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Objective name:</Box>
//                 </Box>
//                 {selectedData.description && (
//                   <Box className="right-column-section">
//                     <Box>Description:</Box>
//                   </Box>
//                 )}
//               </Box>
//             </Box>
//           </Grid>
//         )}

//         {/* Experience Section */}
//         {selectedData.companyName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Experience:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Company Name:</Box>
//                   {selectedData.toDate && <Box>To date:</Box>}
//                   {selectedData.role && <Box>Role:</Box>}
//                 </Box>
//                 <Box className="right-column-section">
//                   {selectedData.fromDate && <Box>From date:</Box>}
//                   {selectedData.skills && <Box>Skills:</Box>}
//                 </Box>
//               </Box>
//             </Box>
//           </Grid>
//         )}

//         {/* Education Section */}
//         {selectedData.instituteName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Education Details:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Institute Name:</Box>
//                   {selectedData.boardUniversity && <Box>Board/University:</Box>}
//                   {selectedData.passingYear && <Box>Passing Year:</Box>}
//                 </Box>
//                 <Box className="right-column-section">
//                   {selectedData.courseName && <Box>Course Name:</Box>}
//                   {selectedData.percentageCGPA && <Box>Percentage/CGPA:</Box>}
//                 </Box>
//               </Box>
//             </Box>
//           </Grid>
//         )}

//         {/* Projects Section */}
//         {selectedData.projectName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Projects:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Project Name:</Box>
//                 </Box>
//                 {selectedData.projectSummary && (
//                   <Box className="right-column-section">
//                     <Box>Project Summary:</Box>
//                   </Box>
//                 )}
//               </Box>
//             </Box>
//           </Grid>
//         )}

//         {/* Certification Section */}
//         {selectedData.certificationName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Certification:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Certification Name:</Box>
//                   {selectedData.issuedDate && <Box>Issued Date:</Box>}
//                   {selectedData.descriptionDetails && <Box>Description or Details:</Box>}
//                 </Box>
//                 <Box className="right-column-section">
//                   {selectedData.issuingOrganization && <Box>Issuing Organization:</Box>}
//                   {selectedData.expirationDate && <Box>Expiration Date:</Box>}
//                 </Box>
//               </Box>
//             </Box>
//           </Grid>
//         )}

//         {/* Language Section */}
//         {selectedData.languageName && (
//           <Grid item xs={12}>
//             <Box className="objective-section">
//               <Box>Language:</Box>
//               <Box className="obj-des-section">
//                 <Box className="left-column-section">
//                   <Box>Language Name:</Box>
//                 </Box>
//               </Box>
//             </Box>
//           </Grid>
//         )}
//       </Grid>
//     </Box>
//   );
// }

// import React, { useState, useEffect } from "react";
// import Grid from "@mui/material/Grid";
// import { useSelector } from "react-redux";
// import SideBar from "./SideBar";
// import { Box, Typography } from "@mui/material";
// import moment from "moment";

// function CvPdfList() {
//   const basicInfoData = useSelector(
//     (state) => state.apiData.selectedBasicInformation
//   );
//   const objectiveData = useSelector(
//     (state) => state.apiData.selectedObjectiveDetails
//   );
//   const expDetailsData = useSelector(
//     (state) => state.apiData.selectedExperienceDetails
//   );
//   const projectDetailsData = useSelector(
//     (state) => state.apiData.selectedProjectDetails
//   );
//   const selectedData = useSelector((state) => state.apiData.selectedpdfData);
//   console.log(selectedData);
//   const [selectedSkills, setSelectedSkills] = useState({});

//   useEffect(() => {
//     const savedSkills = localStorage.getItem("selectedSkills");
//     if (savedSkills) {
//       setSelectedSkills(JSON.parse(savedSkills));
//     }
//   }, []);
//   console.log(objectiveData);

//   return (
//     <Box sx={{ display: "flex" }} className="cv-generate-section">
//       <SideBar />
//       <Box component="main" className="cv-inner-section">
//         <Typography variant="h4">
//           <Box className="cv-text">Template Layout</Box>
//           <Box>
//             <SideBar />
//             <Grid container spacing={2}>
//               <Grid container spacing={2}>
//                 {basicInfoData?.map((basicInfo, index) => (
//                   <Grid item xs={12} key={index}>
//                     <Grid item xs={12}>
//                       <Box className="profile-cv-section">
//                         <Box className="circle-img-section"></Box>
//                         <Box className="pf-img-section">
//                           <Box className="cv-text-heading">
//                             Name :{" "}
//                             <span className="emp-cv-details">
//                               {basicInfo.employeeName}
//                             </span>
//                           </Box>
//                           <Box className="cv-text-heading">
//                             Designation :{" "}
//                             <span className="emp-cv-details">
//                               {basicInfo.designation}
//                             </span>
//                           </Box>
//                           <Box className="cv-text-heading">
//                             Email:{" "}
//                             <span className="emp-cv-details">
//                               {basicInfo.email}
//                             </span>
//                           </Box>
//                           <Box className="cv-text-heading">
//                             Mobile:{" "}
//                             <span className="emp-cv-details">
//                               {basicInfo.mobileNo}
//                             </span>
//                           </Box>
//                           <Box className="cv-text-heading">
//                             LinkedIn:{" "}
//                             <span className="emp-cv-details">
//                               {basicInfo.linkedin}
//                             </span>
//                           </Box>
//                         </Box>
//                       </Box>
//                     </Grid>
//                     <Box className="profile-cv-section">
//                       {objectiveData
//                         ?.filter(
//                           (exp) => exp.employeeCode === basicInfo.empcode
//                         )
//                         ?.map((exp, expIndex) => (
//                           <Box className="objective-section" key={expIndex}>
//                             <Box className="cv-title-text">Objective:</Box>
//                             <Box className="obj-des-section">
//                               <Box className="left-column-section">
//                                 <Box className="cv-text-heading">
//                                   Objective Name:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.employeeObjective}
//                                   </span>
//                                 </Box>
//                               </Box>
//                               <Box right-column-section>
//                                 <Box className="cv-text-heading">
//                                   Objective Description:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.objectiveDescription}
//                                   </span>
//                                 </Box>
//                               </Box>
//                             </Box>
//                           </Box>
//                         ))}
//                     </Box>

//                     <Box className="Exp-cv-section">
//                       {expDetailsData
//                         ?.filter((exp) => exp.empCode === basicInfo.empcode)
//                         ?.map((exp, expIndex) => (
//                           <Box className="objective-section" key={expIndex}>
//                             <Box className="cv-title-text exp-title-cv-text">
//                               Experience:
//                             </Box>
//                             <Box className="obj-des-section">
//                               <Box className="left-column-section">
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   Company Name:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.companyName}
//                                   </span>
//                                 </Box>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   Company Role:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.companyRole}
//                                   </span>
//                                 </Box>
//                               </Box>
//                               <Box right-column-section>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   From Date:{" "}
//                                   <span className="emp-cv-details">
//                                     {moment(exp.fromDate).format("D MMMM YYYY")}
//                                   </span>
//                                 </Box>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   To Date:{" "}
//                                   <span className="emp-cv-details">
//                                     {moment(exp.toDate).format("D MMMM YYYY")}
//                                   </span>
//                                 </Box>
//                               </Box>
//                             </Box>
//                           </Box>
//                         ))}
//                     </Box>

//                     <Box className="Exp-cv-section">
//                       {projectDetailsData
//                         ?.filter((exp) => exp.empCode === basicInfo.empcode)
//                         ?.map((exp, expIndex) => (
//                           <Box className="objective-section" key={expIndex}>
//                             <Box className="cv-title-text exp-title-cv-text">
//                               Project Details:
//                             </Box>
//                             <Box className="obj-des-section">
//                               <Box className="left-column-section">
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   Project Name:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.projectName}
//                                   </span>
//                                 </Box>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   Project Role:{" "}
//                                   <span className="emp-cv-details">
//                                     {exp.projectRole}
//                                   </span>
//                                 </Box>
//                               </Box>
//                               <Box right-column-section>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   From Date:{" "}
//                                   <span className="emp-cv-details">
//                                     {moment(exp.fromDate).format("D MMMM YYYY")}
//                                   </span>
//                                 </Box>
//                                 <Box className="cv-text-heading exp-title-cv-details">
//                                   To Date:{" "}
//                                   <span className="emp-cv-details">
//                                     {moment(exp.toDate).format("D MMMM YYYY")}
//                                   </span>
//                                 </Box>
//                               </Box>
//                             </Box>
//                           </Box>
//                         ))}
//                     </Box>
//                   </Grid>
//                 ))}
//               </Grid>
//             </Grid>
//           </Box>
//         </Typography>
//       </Box>
//     </Box>
//   );
// }

// export default CvPdfList;



import React, { useState, useEffect, useRef } from "react";
import Grid from "@mui/material/Grid";
import { useSelector } from "react-redux";
import SideBar from "./SideBar";
import { Box, Typography, Button } from "@mui/material";
import moment from "moment";
import html2pdf from "html2pdf.js";

function CvPdfList() {
  const basicInfoData = useSelector(
    (state) => state.apiData.selectedBasicInformation
  );
  const objectiveData = useSelector(
    (state) => state.apiData.selectedObjectiveDetails
  );
  const expDetailsData = useSelector(
    (state) => state.apiData.selectedExperienceDetails
  );
  const projectDetailsData = useSelector(
    (state) => state.apiData.selectedProjectDetails
  );
  const selectedData = useSelector((state) => state.apiData.selectedpdfData);
  console.log(selectedData);
  const [selectedSkills, setSelectedSkills] = useState({});

  const cvRef = useRef(null); // Reference to the CV section

  useEffect(() => {
    const savedSkills = localStorage.getItem("selectedSkills");
    if (savedSkills) {
      setSelectedSkills(JSON.parse(savedSkills));
    }
  }, []);
  console.log(objectiveData);

  // Function to download PDF
  const downloadPdf = () => {
    const element = cvRef.current;
    const options = {
      filename: "cv.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "pt", format: "a4", orientation: "portrait" },
    };
    html2pdf().set(options).from(element).save();
  };

  return (
    <Box sx={{ display: "flex" }} className="cv-generate-section">
      <SideBar />
      <Box component="main" className="cv-inner-section">
        <Typography variant="h4">
          <Box className="cv-text">Template Layout</Box>
          <Button variant="contained" color="primary" onClick={downloadPdf}>
            Download PDF
          </Button>
          <Box ref={cvRef}>
            <SideBar />
            <Grid container spacing={2}>
              <Grid container spacing={2}>
                {basicInfoData?.map((basicInfo, index) => (
                  <Grid item xs={12} key={index}>
                    <Grid item xs={12}>
                      <Box className="profile-cv-section">
                        <Box className="circle-img-section"></Box>
                        <Box className="pf-img-section">
                          <Box className="cv-text-heading">
                            Name :{" "}
                            <span className="emp-cv-details">
                              {basicInfo.employeeName}
                            </span>
                          </Box>
                          <Box className="cv-text-heading">
                            Designation :{" "}
                            <span className="emp-cv-details">
                              {basicInfo.designation}
                            </span>
                          </Box>
                          <Box className="cv-text-heading">
                            Email:{" "}
                            <span className="emp-cv-details">
                              {basicInfo.email}
                            </span>
                          </Box>
                          <Box className="cv-text-heading">
                            Mobile:{" "}
                            <span className="emp-cv-details">
                              {basicInfo.mobileNo}
                            </span>
                          </Box>
                          <Box className="cv-text-heading">
                            LinkedIn:{" "}
                            <span className="emp-cv-details">
                              {basicInfo.linkedin}
                            </span>
                          </Box>
                        </Box>
                      </Box>
                    </Grid>
                    <Box className="profile-cv-section">
                      {objectiveData
                        ?.filter(
                          (exp) => exp.employeeCode === basicInfo.empcode
                        )
                        ?.map((exp, expIndex) => (
                          <Box className="objective-section" key={expIndex}>
                            <Box className="cv-title-text">Objective:</Box>
                            <Box className="obj-des-section">
                              <Box className="left-column-section">
                                <Box className="cv-text-heading">
                                  Objective Name:{" "}
                                  <span className="emp-cv-details">
                                    {exp.employeeObjective}
                                  </span>
                                </Box>
                              </Box>
                              <Box right-column-section>
                                <Box className="cv-text-heading">
                                  Objective Description:{" "}
                                  <span className="emp-cv-details">
                                    {exp.objectiveDescription}
                                  </span>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        ))}
                    </Box>

                    <Box className="Exp-cv-section">
                      {expDetailsData
                        ?.filter((exp) => exp.empCode === basicInfo.empcode)
                        ?.map((exp, expIndex) => (
                          <Box className="objective-section" key={expIndex}>
                            <Box className="cv-title-text exp-title-cv-text">
                              Experience:
                            </Box>
                            <Box className="obj-des-section">
                              <Box className="left-column-section">
                                <Box className="cv-text-heading exp-title-cv-details">
                                  Company Name:{" "}
                                  <span className="emp-cv-details">
                                    {exp.companyName}
                                  </span>
                                </Box>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  Company Role:{" "}
                                  <span className="emp-cv-details">
                                    {exp.companyRole}
                                  </span>
                                </Box>
                              </Box>
                              <Box right-column-section>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  From Date:{" "}
                                  <span className="emp-cv-details">
                                    {moment(exp.fromDate).format("D MMMM YYYY")}
                                  </span>
                                </Box>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  To Date:{" "}
                                  <span className="emp-cv-details">
                                    {moment(exp.toDate).format("D MMMM YYYY")}
                                  </span>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        ))}
                    </Box>

                    <Box className="Exp-cv-section">
                      {projectDetailsData
                        ?.filter((exp) => exp.empCode === basicInfo.empcode)
                        ?.map((exp, expIndex) => (
                          <Box className="objective-section" key={expIndex}>
                            <Box className="cv-title-text exp-title-cv-text">
                              Project Details:
                            </Box>
                            <Box className="obj-des-section">
                              <Box className="left-column-section">
                                <Box className="cv-text-heading exp-title-cv-details">
                                  Project Name:{" "}
                                  <span className="emp-cv-details">
                                    {exp.projectName}
                                  </span>
                                </Box>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  Project Role:{" "}
                                  <span className="emp-cv-details">
                                    {exp.projectRole}
                                  </span>
                                </Box>
                              </Box>
                              <Box right-column-section>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  From Date:{" "}
                                  <span className="emp-cv-details">
                                    {moment(exp.fromDate).format("D MMMM YYYY")}
                                  </span>
                                </Box>
                                <Box className="cv-text-heading exp-title-cv-details">
                                  To Date:{" "}
                                  <span className="emp-cv-details">
                                    {moment(exp.toDate).format("D MMMM YYYY")}
                                  </span>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        ))}
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </Grid>
          </Box>
        </Typography>
      </Box>
    </Box>
  );
}

export default CvPdfList;

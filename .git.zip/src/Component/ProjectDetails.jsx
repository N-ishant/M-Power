import React, { useState, useEffect } from "react";
import {
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Box,
  Checkbox,
  TextField,
  IconButton,
} from "@mui/material";
import Loader from "../Component/Loader";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import moment from "moment";
import { setSelectedProjectDetails } from "../feature/apiDataSlice";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

const ProjectDetails = () => {
  const dispatch = useDispatch();
  const baseURL = "https://staffcentral.azurewebsites.net/api";
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingRow, setEditingRow] = useState(null);
  const [editValues, setEditValues] = useState({});

  const selectedEmployees = useSelector(
    (state) => state.apiData.selectedEmployees
  );
  const selectedRows = useSelector(
    (state) => state.apiData.selectedProjectDetails
  );
  console.log(selectedRows);
  
  // Group the data by empCode
  const groupByEmpCode = (records) => {
    return records.reduce((acc, record) => {
      const empCode = record.empCode;
      if (!acc[empCode]) {
        acc[empCode] = [];
      }
      acc[empCode].push(record);
      return acc;
    }, {});
  };

  const refreshList = () => {
    const empCodes = selectedEmployees.join(",");
    const cachedRows = JSON.parse(localStorage.getItem("selectedRows")) || [];

    const uncachedEmpCodes = selectedEmployees
      .filter((empCode) => !cachedRows.some((row) => row.empCode === empCode))
      .join(",");

    if (uncachedEmpCodes) {
      axios
        .get(`${baseURL}/CreateEmployeeCV/GetProjectDetailsByEmpCodes`, {
          params: { empCodes: uncachedEmpCodes },
        })
        .then((response) => {
          const allData = [...cachedRows, ...response.data];
          setData(allData);
          setLoading(false);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
          setLoading(false);
        });
    } else {
      setData(cachedRows);
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshList();
  }, [selectedEmployees]);

  const handleCheckboxChange = (item) => {
    const isSelected = selectedRows.some(
      (row) => row.empCode === item.empCode && row.projectName === item.projectName
    );
    const updatedSelectedRows = isSelected
      ? selectedRows.filter(
          (row) => !(row.empCode === item.empCode && row.projectName === item.projectName)
        )
      : [...selectedRows, item];
    dispatch(setSelectedProjectDetails(updatedSelectedRows));
    localStorage.setItem("selectedRows", JSON.stringify(updatedSelectedRows));
  };

  const isRowSelected = (item) =>
    selectedRows.some(
      (row) => row.empCode === item.empCode && row.projectName === item.projectName
    );

  // Handle edit
  const handleEditClick = (index, item) => {
    const updatedSelectedRows = selectedRows.filter(
      (row) => !(row.empCode === item.empCode && row.projectName === item.projectName)
    );
    dispatch(setSelectedProjectDetails(updatedSelectedRows));
    localStorage.setItem("selectedRows", JSON.stringify(updatedSelectedRows));
    setEditingRow(`${item.empCode}-${item.projectName}`);
    setEditValues({
      projectName: item.projectName,
      projectRole: item.projectRole,
      projectDescription: item.projectDescription,
      fromDate: item.fromDate,
      toDate: item.toDate,
    });
  };

  // Handle save - only update the specific row
  const handleSaveClick = (index, empCode, projectName) => {
    const updatedData = data.map((item) =>
      item.empCode === empCode && item.projectName === projectName
        ? { ...item, ...editValues }
        : item
    );
  
    setData(updatedData);
    setEditingRow(null);
    localStorage.setItem("selectedRows", JSON.stringify(updatedData));
  
    // Update the selectedRows state
    const updatedSelectedRows = updatedData.filter(
      (row) => row.empCode === empCode && row.projectName === projectName
    );
    dispatch(setSelectedProjectDetails(updatedSelectedRows));
    localStorage.setItem("selectedRows", JSON.stringify(updatedSelectedRows));
  };

  // Handle cancel
  const handleCancelClick = () => {
    setEditingRow(null);
  };

  // Handle input change for editing
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditValues((prev) => ({ ...prev, [name]: value }));
  };

  if (selectedEmployees.length < 1) {
    localStorage.removeItem("selectedRows");
  }

  // Group the data by empCode
  const groupedData = groupByEmpCode(data);

  return (
    <Box>
      {loading ? (
        <Loader />
      ) : (
        <>
          {Object.keys(groupedData).map((empCode) => (
            <Container key={empCode}>
              <TableContainer
                className="pd-0 table-project-details-section"
                component={Paper}
              >
                <Typography
                  variant="h7"
                  sx={{ minWidth: 275, mt: 0, pl: 2, pt: 2, pb: 1 }}
                  component="div"
                  gutterBottom
                >
                  Employee Name : {groupedData[empCode][0].employeeName}
                </Typography>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell style={{ width: 50 }}>S.No</TableCell>
                      <TableCell>Project Name</TableCell>
                      <TableCell>Role</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>From Date</TableCell>
                      <TableCell>To Date</TableCell>
                      <TableCell>Selected</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {groupedData[empCode].map((item, rowIndex) => (
                      <TableRow key={`${item.empCode}-${item.projectName}`}>
                        <TableCell>{rowIndex + 1}</TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <TextField
                              name="projectName"
                              value={editValues.projectName}
                              onChange={handleInputChange}
                            />
                          ) : (
                            item.projectName
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <TextField
                              name="projectRole"
                              value={editValues.projectRole}
                              onChange={handleInputChange}
                            />
                          ) : (
                            item.projectRole
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <TextField
                              name="projectDescription"
                              value={editValues.projectDescription}
                              onChange={handleInputChange}
                            />
                          ) : (
                            item.projectDescription
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <TextField
                              name="fromDate"
                              value={moment(editValues.fromDate).format("YYYY-MM-DD")}
                              onChange={handleInputChange}
                              type="date"
                            />
                          ) : (
                            moment(item.fromDate).format("DD-MM-YYYY")
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <TextField
                              name="toDate"
                              value={moment(editValues.toDate).format("YYYY-MM-DD")}
                              onChange={handleInputChange}
                              type="date"
                            />
                          ) : (
                            moment(item.toDate).format("DD-MM-YYYY")
                          )}
                        </TableCell>
                        <TableCell>
                          <Checkbox
                            checked={isRowSelected(item)}
                            onChange={() => handleCheckboxChange(item)}
                            disabled={editingRow === `${item.empCode}-${item.projectName}`}
                          />
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.projectName}` ? (
                            <>
                              <IconButton
                                onClick={() =>
                                  handleSaveClick(rowIndex, item.empCode, item.projectName)
                                }
                              >
                                <SaveIcon />
                              </IconButton>
                              <IconButton onClick={handleCancelClick}>
                                <CancelIcon />
                              </IconButton>
                            </>
                          ) : (
                            <IconButton
                              onClick={() => handleEditClick(rowIndex, item)}
                            >
                              <EditIcon />
                            </IconButton>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Container>
          ))}
        </>
      )}
    </Box>
  );
};

export default ProjectDetails;

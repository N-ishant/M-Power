import React, { useState, useEffect } from "react";
import {
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Box,
  Checkbox,
  TextField,
  IconButton,
} from "@mui/material";
import Loader from "../Component/Loader";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import moment from "moment";
import { setSelectedExperienceDetails } from "../feature/apiDataSlice";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

const ExperienceDetails = () => {
  const dispatch = useDispatch();
  const baseURL = "https://staffcentral.azurewebsites.net/api";
  const [data, setData] = useState([]); // Store all records
  const [loading, setLoading] = useState(true);
  const [editingRow, setEditingRow] = useState(null); // Track which row is being edited
  const [editValues, setEditValues] = useState({}); // Store edited values

  const selectedEmployees = useSelector(
    (state) => state.apiData.selectedEmployees
  );
  const selectedRows = useSelector(
    (state) => state.apiData.selectedExperienceDetails
  );

  // Group the data by empCode
  const groupByEmpCode = (records) => {
    return records.reduce((acc, record) => {
      const empCode = record.empCode;
      if (!acc[empCode]) {
        acc[empCode] = [];
      }
      acc[empCode].push(record);
      return acc;
    }, {});
  };

  // Refresh the list and fetch new data if needed
  const refreshList = () => {
    const empCodes = selectedEmployees.join(",");
    const cachedRows = JSON.parse(localStorage.getItem("experienceData")) || [];

    const uncachedEmpCodes = selectedEmployees
      .filter((empCode) => !cachedRows.some((row) => row.empCode === empCode))
      .join(",");

    if (uncachedEmpCodes) {
      axios
        .get(`${baseURL}/CreateEmployeeCV/GetExprienceDetailsByEmpCodes`, {
          params: { empCodes: uncachedEmpCodes },
        })
        .then((response) => {
          const allData = [...cachedRows, ...response.data.map((item) => ({
            ...item,
            isChecked: false, // Initialize unchecked state for new data
          }))];
          setData(allData);
          localStorage.setItem("experienceData", JSON.stringify(allData));
          setLoading(false);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
          setLoading(false);
        });
    } else {
      setData(cachedRows);
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshList();
  }, [selectedEmployees]);

  // Handle checkbox change
  const handleCheckboxChange = (item) => {
    const updatedData = data.map((row) =>
      row.empCode === item.empCode && row.companyName === item.companyName
        ? { ...row, isChecked: !row.isChecked } // Toggle checked state
        : row
    );
    setData(updatedData);

    // Update selected rows in Redux store
    const updatedSelectedRows = updatedData.filter((row) => row.isChecked);
    dispatch(setSelectedExperienceDetails(updatedSelectedRows));

    // Persist to localStorage
    localStorage.setItem("experienceData", JSON.stringify(updatedData));
  };

  const isRowSelected = (item) => item.isChecked;

  // Handle edit
  const handleEditClick = (item) => {
    setEditingRow(`${item.empCode}-${item.companyName}`);
    setEditValues({
      companyName: item.companyName,
      companyRole: item.companyRole,
      fromDate: item.fromDate,
      toDate: item.toDate,
    });
  };

  // Handle save - update only the specific row
  const handleSaveClick = (empCode, companyName) => {
    const updatedData = data.map((item) =>
      item.empCode === empCode && item.companyName === companyName
        ? { ...item, ...editValues } // Create a new object with updated values
        : item
    );
    setData(updatedData);
    setEditingRow(null);
    localStorage.setItem("experienceData", JSON.stringify(updatedData));
  };

  // Handle cancel
  const handleCancelClick = () => {
    setEditingRow(null);
  };

  // Handle input change for editing
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditValues((prev) => ({ ...prev, [name]: value }));
  };

  if (selectedEmployees.length < 1) {
    localStorage.removeItem("experienceData");
  }

  const groupedData = groupByEmpCode(data);
  console.log(selectedRows);
  return (
    <Box>
      {loading ? (
        <Loader />
      ) : (
        <>
          {Object.keys(groupedData).map((empCode) => (
            <Container key={empCode}>
              <TableContainer
                className="pd-0 table-experience-details-section"
                component={Paper}
              >
                <Typography
                  variant="h7"
                  sx={{ minWidth: 275, mt: 0, pl: 2, pt: 2, pb: 1 }}
                  component="div"
                  gutterBottom
                >
                  Employee Name : {groupedData[empCode][0].employeeName}
                </Typography>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell style={{ width: 50 }}>S.No</TableCell>
                      <TableCell>Company Name</TableCell>
                      <TableCell>Role</TableCell>
                      <TableCell>From Date</TableCell>
                      <TableCell>To Date</TableCell>
                      <TableCell>Selected</TableCell>
                      <TableCell>Edit</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {groupedData[empCode].map((item, rowIndex) => (
                      <TableRow key={`${item.empCode}-${item.companyName}`}>
                        <TableCell>{rowIndex + 1}</TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.companyName}` ? (
                            <TextField
                              name="companyName"
                              value={editValues.companyName}
                              onChange={handleInputChange}
                            />
                          ) : (
                            item.companyName
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.companyName}` ? (
                            <TextField
                              name="companyRole"
                              value={editValues.companyRole}
                              onChange={handleInputChange}
                            />
                          ) : (
                            item.companyRole
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.companyName}` ? (
                            <TextField
                              name="fromDate"
                              value={moment(editValues.fromDate).format(
                                "YYYY-MM-DD"
                              )}
                              onChange={handleInputChange}
                            />
                          ) : (
                            moment(item.fromDate).format("DD-MM-YYYY")
                          )}
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.companyName}` ? (
                            <TextField
                              name="toDate"
                              value={moment(editValues.toDate).format(
                                "YYYY-MM-DD"
                              )}
                              onChange={handleInputChange}
                            />
                          ) : (
                            moment(item.toDate).format("DD-MM-YYYY")
                          )}
                        </TableCell>
                        <TableCell>
                          <Checkbox
                            checked={isRowSelected(item)}
                            onChange={() => handleCheckboxChange(item)}
                          />
                        </TableCell>
                        <TableCell>
                          {editingRow === `${item.empCode}-${item.companyName}` ? (
                            <>
                              <IconButton
                                onClick={() =>
                                  handleSaveClick(
                                    item.empCode,
                                    item.companyName
                                  )
                                }
                              >
                                <SaveIcon />
                              </IconButton>
                              <IconButton onClick={handleCancelClick}>
                                <CancelIcon />
                              </IconButton>
                            </>
                          ) : (
                            <IconButton
                              onClick={() => handleEditClick(item)}
                            >
                              <EditIcon />
                            </IconButton>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Container>
          ))}
        </>
      )}
    </Box>
  );
};

export default ExperienceDetails;

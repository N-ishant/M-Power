import React from 'react'
import SideBar from '../Component/SideBar'
import { Tabs, Tab, Box, Grid, Button, Card, Breadcrumbs, Link, Typography, AppBar, Toolbar } from '@mui/material';
import CreatecvEmployeeTable from '../Component/CreatecvEmployeeTable';
import Objective from '../Component/Objective';
import Addskillsandexperience from '../Component/Addskillsandexperience';
import Setuptemplate from '../Component/Setuptemplate';
import ExperienceDetails from './ExperienceDetails';
import ProjectDetails from '../Component/ProjectDetails';


import { useSelector } from 'react-redux';

function CreateCV() {
  const baseURL = 'https://staffcentral.azurewebsites.net/api';
  const selectedEmployees = useSelector((state) => state.apiData.selectedEmployees);
  console.log(selectedEmployees);
  
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
 
  const handleNext = () => {
    setValue((prevValue) => Math.min(prevValue + 1, steps.length - 1));
  };

  const handleBack = () => {
    setValue((prevValue) => Math.max(prevValue - 1, 0));
  };

  const steps = [
    { label: 'Employee List', content: <StepOneContent /> },
    { label: 'Objective', content: <StepTwoContent /> },
    { label: 'Experience Details', content: <StepThreeContent /> },
    { label: 'Project Details', content: <StepFourContent /> },
    { label: 'Skills & Technologies', content: <StepFiveContent /> },
    { label: 'Setup Template', content: <StepSixContent /> },
  ];
  function handleClick(event) {
    event.preventDefault();
    console.info('You clicked a breadcrumb.');
  } 
  return (
    <Box sx={{ display: 'flex' }} className="main-container ">
    <SideBar />
    <Box component="main" className="main-content" sx={{ flexGrow: 1, }}>
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={8}>
        <Typography className='head-title' component="h1" variant="h6" align="left">
        Create CV
        </Typography>
        </Grid>
        <Grid item xs={4} textAlign={'right'}>
            <div role="presentation" onClick={handleClick}>
            <Breadcrumbs className='breadcrumbs-css' aria-label="breadcrumb" textAlign={'right'} sx={{ mt: 1 }}>
            <Link underline="hover" color="inherit" href="/">
            CV Generation
            </Link>
            <Typography color="text.primary">Create CV</Typography>
          </Breadcrumbs>
        </div>
        </Grid>
      </Grid>
    </Box>

    <Card sx={{ minWidth: 275, mt:0, pb:1 }}>
    <Grid container spacing={2}>
      <Grid item xs={12} sx={{ mt:0, pt:0 }}>
      <Tabs className='tab-button-2' value={value} onChange={handleChange} variant="fullWidth" sx={{ borderBottom: 1, borderColor: 'divider' }}>
        {steps.map((step, index) => (
          <Tab key={index} label={step.label} />
        ))}
      </Tabs>
      <Box sx={{ p: 3 }}>
        {steps[value].content}
      </Box>
    
      <Grid item xs={12} sx={{ mb: 2, pl:2, pr:3 }} textAlign={'right'}>
     
        <Button
          disabled={value === 0}
          onClick={handleBack}
          variant="contained"
          className='dic-css mr-10'
        >
          Back
        </Button>
        <Button sx={{ mt: 0, mr:2 }}
          disabled={value === steps.length - 1}
          onClick={handleNext}
          variant="contained"
          className="primary"
        >
          Next
        </Button>
     
      </Grid>
      </Grid>
    </Grid>   
    </Card>
    </Box>
  </Box>
  )
}


const StepOneContent = () => (
  <Box>
    <CreatecvEmployeeTable/>
  </Box>
);

const StepTwoContent = () => (
  <Box>
    <Objective/>
  </Box>
);

const StepThreeContent = () => (
  <Box>
    <ExperienceDetails/>
  </Box>
);

const StepFourContent = () => (
  <Box>
    <ProjectDetails/>
  </Box>
);

const StepFiveContent = () => (
  <Box>
    <Addskillsandexperience/>
  </Box>
);

const StepSixContent = () => (
  <Box>
    <Setuptemplate/>
  </Box>
);

export default CreateCV
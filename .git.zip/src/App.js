import React from 'react'
import { Routes, Route, BrowserRouter } from "react-router-dom"
import Dashboard from './Page/Dashboard'
import Management from './Page/Management'
import Live from './Page/Live'
import Reports from './Page/Reports'
import Login from './Component/Login/Login'
import Registration from './Component/Resister/Registration'
import Forgotpassword from './Component/Forgotpassword/Forgotpassword'
import Settings from './Page/Settings'
import Resetpassword from './Component/Forgotpassword/Resetpassword'
import RoleMaster from './Page/RoleMaster'
import SkillMaster from './Page/SkillMaster'
import GeneratedCV from './Page/GeneratedCV'

import UserRoleMapping from './Page/UserRoleMapping'
import UserManagement from './Page/UserManagement'
import PersonalDetails from './Page/PersonalDetails'
import EducationDeatils from './Page/EducationDeatils'
import ExperienceDetails from './Page/ExperienceDetails'
import DesignationMaster from './Page/DesignationMaster'
import DocumentTypeMaster from './Page/DocumentTypeMaster'
import TransactionMaster from './Page/TransactionMaster'
import Profile from './Page/Profile'
import ChangePassword from './Page/ChangePassword'
import UserandRoleMapping from './Page/UserandRoleMapping'
import UserRoleAccess from './Page/UserRoleAccess'
import Master from './Page/Master'
import UploadDocuments from './Page/UploadDocuments'
import TemplateMaster from './Page/TemplateMaster'
import ClientMaster from './Page/ClientMaster'
import ObjectiveMaster from './Page/ObjectiveMaster'
import CreateCV from './Page/CreateCV'
import EmployeeDetails from './Page/EmployeeDetails'
import { useState, useEffect } from 'react';
import axios from 'axios';
import { Grid } from '@mui/material';
import ViewDetailsList from './Component/ViewDetailsList';
import CvPdfList from './Component/CvPdfList'

export default function App() {
  // const baseURL = 'https://staffcentral.azurewebsites.net/api';
  // const [moduleLinksByRole, setModuleLinksByRole] = useState([]);

  // let roles = sessionStorage.getItem('employeeRoles');
  
  // useEffect(() => {
  //   axios.get(baseURL + '/LinkRoleMapping/GetAllLink-RoleMappingView')
  //     .then(response => {

  //       if (roles != null) {
  //         roles = sessionStorage.getItem('employeeRoles').split(',');

  //         // Filter data based on roleText
  //         const filteredData = response.data.filter(item => roles.includes(item.roleText.trim()));
  
  //         // Merge data based on moduleName
  //         const mergedData = filteredData.reduce((acc, curr) => {
  //           const existingModule = acc.find(item => item.moduleName === curr.moduleName);
  //           if (existingModule) {
  //             // Merge and remove duplicates for moduleLinkId
  //             const moduleLinkIdSet = new Set([...existingModule.moduleLinkId.split(', '), ...curr.moduleLinkId.split(', ')]);
  //             existingModule.moduleLinkId = Array.from(moduleLinkIdSet).join(', ');
  
  //             // Merge and remove duplicates for linkNames
  //             const linkNamesSet = new Set([...existingModule.linkNames.split(', '), ...curr.linkNames.split(', ')]);
  //             existingModule.linkNames = Array.from(linkNamesSet).join(', ');
  
  //             // Merge roleId and roleText as it is unique no need to remove duplicates
  //             existingModule.roleId += `, ${curr.roleId}`;
  //             existingModule.roleText += `, ${curr.roleText}`;
  //           } else {
  //             acc.push(curr);
  //           }
  //           return acc;
  //         }, []);
  //         setModuleLinksByRole(mergedData);
  //       }
  //     })
  //     .catch(error => {
  //       console.error('Error fetching data:', error);
  //     });
  // }, []);


  return (
    <>

      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/login' element={<Login />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/forgotpassword" element={<Forgotpassword />} />
          <Route path="/resetpassword" element={<Resetpassword />} />
          <Route path='/dashboard' element={<Dashboard />}></Route>
          <Route path='/live' element={<Live />}></Route>
          <Route path='/management' element={<Management />}></Route>
          <Route path='/setting' element={<Settings />}></Route>
          <Route path='/report' element={<Reports />}></Route>
          <Route path='*' element={<Login />} />

          <Route path='/usermanagement' element={<UserManagement />}></Route>
          <Route path='/personalDetails' element={<PersonalDetails />}></Route>
          <Route path='/educationDeatils' element={<EducationDeatils />}></Route>
          <Route path='/experienceDetails' element={<ExperienceDetails />}></Route>
          <Route path='/master' element={<Master />}></Route>
          <Route path='/uploaddocument' element={<UploadDocuments />}></Route>
          {/* Role Management Module */}
          <Route path='/rolemaster' element={<RoleMaster />}></Route>
          
              <Route path='/userrolemapping' element={<UserRoleMapping />}></Route>
              <Route path='/userandrolemapping' element={<UserandRoleMapping />}></Route>
              <Route path='/userroleaccess' element={<UserRoleAccess />}></Route>

              {/* Employee Management Module */}
              <Route path='/designationMaster' element={<DesignationMaster />}></Route>
              <Route path='/documentTypeMaster' element={<DocumentTypeMaster />}></Route>
              <Route path='/skillMaster' element={<SkillMaster />}></Route>
              <Route path='/employeedetails' element={<EmployeeDetails />}></Route>
              <Route path='/transactionMaster' element={<TransactionMaster />}></Route>

              {/* User Management Module */}
              <Route path='/Profile' element={<Profile />}></Route>
              <Route path='/changepassword' element={<ChangePassword />}></Route>

              {/* CV Generation Module */}
              <Route path='/templatemaster' element={<TemplateMaster />}></Route>
              <Route path='/Objectivemaster' element={<ObjectiveMaster />}></Route>
              <Route path='/clientmaster' element={<ClientMaster />}></Route>
              <Route path='/createCV' element={<CreateCV />}></Route>
              <Route path='/generatedCV' element={<GeneratedCV />}></Route>
              <Route path='/ViewDetailsList' element={<ViewDetailsList />}></Route>
              <Route path='/CvPdfList' element={<CvPdfList />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}


